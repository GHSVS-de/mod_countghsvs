<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;

$skillsets = $params->get('skillsets', []);

if (empty($skillsets))
{
	return '';
}

$document = Factory::getDocument();

HTMLHelper::_('stylesheet', 'mod_jd_skillset.min.css', array('relative' => true, 'version' => 'auto'));

$numberPosition = $params->get('numberPosition','above');
$symbolPosition = $params->get('symbolPosition','default');

$i = 0;

foreach($skillsets as $skillset)
{
	$i++;
}

if ($i==1)
{
	$count = 12;
}
elseif ($i == 2)
{
	$count = 6;
}
elseif ($i == 3)
{
	$count=4;
}
elseif($i==4)
{
	$count=3;
}

$css = array();

if ($params->get('customsStyle'))
{
	$titleColor = $params->get('titleColor', '');
	$numberColor = $params->get('numberColor', '');
	$symbolColor = $params->get('symbolColor', '');
	$iconColor = $params->get('iconColor', '');
	$titleSize = $params->get('titleSize', 20);
	$numberSize = $params->get('numberSize', 40);
	$symbolSize = $params->get('symbolSize', 40);
	$iconSize = $params->get('iconSize', 52);

	$pre = '.single-skillset.skillset-' . $module->id . ' ';
	$css[] = $pre . '.counter-title{font-size:' . $titleSize . 'px;color:' . $titleColor . '}';
	$css[] = $pre . '.counter-number .count{font-size:' . $numberSize . 'px;color:' . $numberColor . '}';
	$css[] = $pre . '.counter-number .symbol{font-size:' . $symbolSize . 'px;color:' . $symbolColor . '}';
	$css[] = $pre . '.count-icon{font-size:' . $iconSize . 'px;color:' . $iconColor . '}';

	$document->addStyleDeclaration(implode('', $css));
}
?>

<div id="jd_skillset<?php echo $module->id; ?>" class="row pb-lg-3 counter-sub-container skillset-not-counted <?php if($params->get('IconPosition')=='left') echo 'jd-icon-position-left'; ?><?php if($params->get('IconPosition')=='right') echo 'jd-icon-position-right'; ?> ">
	<?php foreach($skillsets as $key => $skillset) : ?>
		<div class="col-12 col-sm-6 col-lg-<?php echo $count;?>
			single-skillset skillset-<?php echo $module->id; ?>">

			<div class="counter-wrapper">
				<?php if($params->get('IconPosition') == 'top' or $params->get('IconPosition') == 'right' or $params->get('IconPosition') == 'left') { ?>
						<?php if($skillset->skillset_icon_option == 'upload') { ?>
							<?php if(!empty($skillset->skillset_icon_upload)) {?>
								<div class="counter-icon">
									<img alt="" src="<?php echo $skillset->skillset_icon_upload; ?>">
								</div>
							<?php } ?>
						<?php }elseif($skillset->skillset_icon_option == 'icon'){ ?>
							<?php if(!empty($skillset->skillset_icon_icon)) {?>
									<div class="counter-icon">
										<i class="<?php echo $skillset->skillset_icon_icon; ?> count-icon" alt="icon"></i>
									</div>
							<?php }?>
						<?php }?>
					<?php } ?>
				<?php if(!empty($skillset->skillset_title) or !empty($skillset->skillset_number)) { ?>
					<div class="counter-text-container">
						<?php if($numberPosition=='above'){ ?>
							<?php if(!empty($skillset->skillset_number)) { ?>
								<p class="counter-number">
									<span class="count"><?php echo $skillset->skillset_number; ?></span>
									<?php
										if(($skillset->skillset_enable_symbol)) { ?>
											<span><<?php if($symbolPosition == 'sub') { echo 'sub';} elseif($symbolPosition == 'sup') { echo "sup"; } else { echo 'span';} ?> class="symbol"><?php echo $skillset->skillset_symbol; ?><?php if($symbolPosition == 'sub') { echo '</sub>';} elseif($symbolPosition == 'sup') { echo "</sup>"; } else { '</span>'; } ?>
											</span>
									<?php } ?>
								</p>
							<?php } ?>
						<?php } ?>
						<?php if(!empty($skillset->skillset_title)) { ?>
							<p class="counter-title"><?php echo $skillset->skillset_title; ?></p>
						<?php }?>

						<?php if($numberPosition=='below'){ ?>
							<?php if(!empty($skillset->skillset_number)) { ?>
								<p class="counter-number">
									<span class="count"><?php echo $skillset->skillset_number; ?></span>
									<?php
										if(($skillset->skillset_enable_symbol)) { ?>
											<span><<?php if($symbolPosition == 'sub') { echo 'sub';} elseif($symbolPosition == 'sup') { echo "sup"; } else { echo 'span';} ?> class="symbol"><?php echo $skillset->skillset_symbol; ?><?php if($symbolPosition == 'sub') { echo '</sub>';} elseif($symbolPosition == 'sup') { echo "</sup>"; } else { '</span>'; } ?>
											</span>
									<?php } ?>
								</p>
							<?php } ?>
						<?php } ?>
					</div>
				<?php } ?>
				<?php if($params->get('IconPosition') == 'bottom') { ?>
						<?php if($skillset->skillset_icon_option == 'upload') { ?>
							<?php if(!empty($skillset->skillset_icon_upload)) {?>
								<div class="counter-icon">
									<img alt="" src="<?php echo $skillset->skillset_icon_upload; ?>">
								</div>
							<?php } ?>
						<?php }elseif($skillset->skillset_icon_option == 'icon'){ ?>
							<?php if(!empty($skillset->skillset_icon_icon)) {?>
									<div class="counter-icon">
										<i class="<?php echo $skillset->skillset_icon_icon; ?> count-icon" alt="icon"></i>
									</div>
							<?php }?>
						<?php }?>
					<?php } ?>
			</div>
		</div>
	<?php endforeach; ?>
</div>

<?php
$js = "(function ($)
{
	// Skillset Number Counter
	var initskillsetcounter = function(_element)
	{
		$(_element).find('.count').each(function()
		{
			$(this).prop('Counter', 0).animate(
				{
					Counter: $(this).text()
				},
				{
					duration: 3000,
					easing: 'swing',
					step: function (now) {
						$(this).text(new Intl.NumberFormat('de-DE').format(Math.ceil(now)));
					}
				}
			);
		}
		);
	};

	var elementInViewport = function (element)
	{
		var _this = element;
		var _this_top = _this.offset().top;
		return (_this_top <= window.pageYOffset + parseInt(window.innerHeight)) && (_this_top >= window.pageYOffset);
	};
	// Events
	var docReady = function ()
	{
		//initskillsetcounter();
	};
	var winScroll = function()
	{
		var _element = $('#jd_skillset" . $module->id .".skillset-not-counted');
		if(typeof _element != 'undefined' && _element.length != 0 && elementInViewport(_element))
		{
			$(_element).removeClass('skillset-not-counted');
			initskillsetcounter(_element);
		}
	};
	$(docReady);
	$(window).scroll(winScroll);
})(jQuery);";

$document->addScriptDeclaration($js);
